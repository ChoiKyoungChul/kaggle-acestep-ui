import os, shutil, subprocess
print("which nvidia-smi:", shutil.which("nvidia-smi"))
print("PATH:", os.environ.get("PATH"))
print("/opt/bin:", os.listdir("/opt/bin") if os.path.isdir("/opt/bin") else None)
print("dev nvidia:", [d for d in os.listdir("/dev") if "nvidia" in d])
print("env:", {k: v for k, v in os.environ.items() if "KAGGLE" in k or "CUDA" in k or "NVIDIA" in k})
try:
    import torch
    print("torch", torch.__version__, "cuda", torch.cuda.is_available(), torch.cuda.device_count())
    for i in range(torch.cuda.device_count()):
        print(i, torch.cuda.get_device_name(i), torch.cuda.get_device_properties(i).total_memory // 2**20, "MB")
except Exception as e:
    print("torch err", e)
print(subprocess.run("nvidia-smi", shell=True, capture_output=True, text=True).stdout[:1500])
