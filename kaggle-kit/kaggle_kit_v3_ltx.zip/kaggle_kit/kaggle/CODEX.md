# Codex 용 Kaggle 작업 지침 — ACE-Step · Krea 2 · YuE2 · LTX-2.5

Codex(또는 다른 AI 코딩 도구)가 Kaggle 무료 GPU 로 곡 · 이미지를 만들 때 **이 문서만 따른다.**
설치 · 노트북 작성 · 다른 방법 찾기를 하지 않는 것이 핵심이다. 지금까지 헤맨 원인은 거의 다 "직접 설치하려다 막힌 것"이었다.

## 0. 절대 하지 않는 것

- ACE-Step · Krea · YuE2 를 **PC 에 pip 로 설치하지 않는다.** GitHub 공식 저장소를 clone 하지 않는다.
- **Kaggle 노트북을 새로 짜지 않는다.** 빌더(`build_*_batch.py`)가 만든 노트북이 Kaggle 안에서 설치 · 모델 받기 · 생성을 다 한다.
- 실행 중 로그가 안 보인다고 **다시 올리거나 다른 방법으로 넘어가지 않는다.** 준비만 약 9분, 곡 하나 약 11분 걸린다. 상태(`running`)면 기다린다.
- 토큰 파일 내용을 출력하거나 채팅 · 문서 · 커밋에 적지 않는다.
- 남이 만든 노트북 · 결과 폴더(`notebookc6fe785625` 등)는 지우지 않는다.

## 1. 시작 전 점검 (한 번)

```powershell
$env:PYTHONUTF8=1                     # 한국어 Windows cp949 오류 방지 — 모든 명령에 필요
python -m kaggle --version            # 없으면 python -m pip install "kaggle==2.2.4"
Test-Path $HOME\.kaggle\access_token  # True 여야 한다 (내용은 보지 않는다)
python -m kaggle kernels list --mine  # 오류 없이 목록이 나오면 인증 OK
```

- **계정 이름을 맞춘다.** 빌더 기본값은 `motionchoi` 다. 다른 계정 토큰이면 `$env:KAGGLE_USER="<내 Kaggle 아이디>"` 를 먼저 설정하거나 빌더에 `--user <아이디>` 를 붙인다. 안 맞으면 push 가 `403 / Permission denied` 로 실패한다 — **다른 PC 실패 1순위 원인.**
- 계정은 kaggle.com Settings 에서 **휴대폰 인증**이 되어 있어야 GPU · 인터넷이 붙는다.
- Codex 실행 권한: 이 작업은 인터넷(`kaggle` CLI)과 `~/kaggle` 폴더 쓰기가 필요하다. 샌드박스가 막으면 사용자에게 "네트워크 허용 / 전체 권한으로 승인"을 요청하고, 우회 방법을 찾지 않는다.

## 2. 곡 만들기 (ACE-Step) — 이 4단계만

1. 작업 파일 작성 — 예시 `~/kaggle/jobs/chungking_ace.json`
   ```json
   {"lyrics": "[Verse 1]\n...", "language": "ko", "seconds": 215, "bpm": 96, "key": "C major",
    "seeds": [5, 23], "styles": {"ballad": "스타일 문구(영어 태그)"}}
   ```
   반주만: lyrics 에 `[Instrumental]`, 스타일에 `no vocals`.
2. 노트북 만들기
   ```powershell
   cd $HOME\kaggle
   python build_song_batch.py ace <작업.json> --slug ace-<이름>
   ```
3. 올리기 → 대기 → 내려받기 → 삭제 (백그라운드로)
   ```powershell
   python kg.py run ace-<이름> --to <결과 폴더>
   ```
4. 결과 `~/kaggle/ace-<이름>-out/outputs/*.mp3` → **사용자가 직접 듣고 고른다.** STT 로 순위를 매기지 않는다.

이미지(Krea 2): `python build_krea_batch.py <job_img.json> --slug krea-<이름>` → `python kg.py run krea-<이름> --to <폴더>`
YuE2(비상업 전용): `python build_song_batch.py yue2 <작업.json> --slug yue2-<이름>` → 같은 `kg.py run`.

## 2-1. 영상 만들기 (LTX-2.5, 사진 → 5초 영상 + 소리)

HF 토큰 필요 없음. 모델 약 40GB 는 노트북이 Kaggle 안에서 받는다(약 3분). PC 에 아무것도 설치하지 않는다.
1. 작업 파일 — 예시 `~/kaggle/jobs/ltx_test.json`. `src` 는 컷 이미지 폴더(작업 파일 기준 상대 경로), 이미지 이름 = 컷 `name`(.png/.jpg)
   ```json
   {"src": "이미지폴더", "seed": 4242, "style": "모든 컷에 붙는 공통 문구(카메라 · 빛 · 소리)",
    "shots": [{"name": "c01", "secs": 5, "prompt": "이 컷의 움직임 · 소리"}]}
   ```
2. `python build_ltx_batch.py <작업.json> --slug ltx-<이름> [--res 704] [--only c01,c02]`
3. `python kg.py run ltx-<이름> --to <결과 폴더>` (백그라운드)
4. 결과 `outputs/<컷이름>.mp4` (1280×704 · 24fps · AAC 소리) + `log.json`

- 속도(11/2 실측, T4 ×2): 704p 5초 컷 **약 6분**(디노이즈 37초/스텝 × 8), 준비(설치 + 모델 받기 + 불러오기) 약 7분. 10컷이면 약 70분.
- 더 빨리: `--res 480`(T4 권장값). 1088p 는 매우 느림.
- 세로 이미지(9:16)는 자동으로 세로 영상이 된다. 한 노트북에 컷을 너무 많이 넣지 말고 10컷 안팎으로 나눠 두 자리에 동시에 올린다.

## 2-2. Kaggle 에 일괄 도구가 없는 모델

Wan 2.2 · Qwen-Image · Z-Image 는 아직 Kaggle 일괄 빌더가 없다. **직접 설치를 시도하지 말고** 사용자에게 알린다(Runpod 템플릿 또는 빌더 추가 요청).

## 3. 끝나면

- `python kg.py usage` 로 이번 주 사용 시간 · 남은 시간을 사용자에게 알린다(주 30시간, 토요일 09:00 KST 초기화).

## 4. 오류가 나면 — 이 표부터

| 증상 | 원인 | 할 일 |
|---|---|---|
| `UnicodeEncodeError: 'cp949'` | 한국어 Windows 인코딩 | `$env:PYTHONUTF8=1` 후 다시 |
| push `403` · `Permission denied` | 빌더 계정(기본 motionchoi) ≠ 토큰 계정 | `--user <내 아이디>` 또는 `KAGGLE_USER` |
| `401 Unauthenticated` | 토큰 없음 · 만료 | 사용자에게 Settings › API › Create New Token 요청, `~/.kaggle/access_token` 에 저장 |
| push 가 계속 거절 · 대기 | GPU 세션 동시 2개 한도 | kg.py 가 90초마다 재시도 — 기다린다 |
| `running` 이 10분 넘게 그대로 | 정상(모델 준비 9분 + 곡당 11분) | 기다린다. 재업로드 금지 |
| 상태 `error` | 노트북 안 오류 | `~/kaggle/<이름>-out/*.log` 를 읽고 **빌더를 고친다** |
| GPU 가 안 붙음 · `Internet disabled` | 휴대폰 인증 안 됨 | 사용자에게 kaggle.com 휴대폰 인증 요청 |
| 소리가 깨짐 · NaN | T4 에서 int8 양자화 | 빌더 기본값(int8 끔 · float32) 유지 |
| XL base 메모리 부족 | T4 16GB 한계 | turbo 모델 사용, XL base 편곡은 Runpod |
| 네트워크 차단 · `kaggle` 연결 실패 | Codex 샌드박스 | 사용자에게 네트워크 허용 요청 |

## 5. 화면(Gradio)으로 직접 만지고 싶을 때

설치 없이 원클릭 노트북을 쓴다(Codex 가 할 일 없음 — 사용자에게 안내만).
- Kaggle: `elrohm0119/ace-step-1-5-one-click-gradio` → Copy & Edit → Settings 에서 Internet on · GPU T4 → Run All → 마지막 셀의 gradio.live 주소
- GitHub: https://github.com/ChoiKyoungChul/kaggle-acestep-ui (ACE · Krea · LTX · YuE2 등 원클릭 모음)

## 폴더

| 경로 | 내용 |
|---|---|
| `build_song_batch.py` · `build_krea_batch.py` · `build_ltx_batch.py` | 작업 json → 노트북 폴더 |
| `kg.py` | 올리기 · 대기 · 내려받기 · 삭제 · 사용 시간 |
| `src-ace-step` · `krea-src` · `src-yue2-music` · `src-ltx25` | 원본 노트북(빌더가 읽는다, 지우지 말 것) |
| `jobs/` | 작업 파일 예시 |
| `README.md` | 자세한 설명 · 다른 계정 사용법 |
