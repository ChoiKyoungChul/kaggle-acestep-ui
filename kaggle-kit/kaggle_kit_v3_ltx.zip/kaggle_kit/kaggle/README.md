# Kaggle 무료 GPU 작업 폴더

Kaggle 무료 GPU(T4 16GB ×2, 주 30시간)로 이미지(Krea 2 Turbo) · 곡(ACE-Step 1.5 XL, YuE2)을 일괄 생성한다.
Claude Code · Codex 등 어떤 AI 도구든 이 문서의 명령을 그대로 쓴다.

> **ACE-Step · Krea · YuE2 를 직접 설치하지 않는다.** 아래 빌더가 만든 노트북이 Kaggle 안에서 설치 · 모델 받기 · 생성까지 다 한다. 할 일은 작업 json 작성 → `build_*_batch.py` → `kg.py run` 세 가지뿐이다.

## 준비 (한 번만)

1. kaggle.com 가입 → Settings 에서 **휴대폰 인증**(안 하면 GPU · 인터넷이 안 붙는다).
2. Settings › API › Create New Token → 토큰을 `~/.kaggle/access_token` 파일에 저장(권한 600). **토큰을 채팅 · 문서 · 커밋에 적지 않는다.**
3. `python -m pip install "kaggle==2.2.4"`. 확인: `PYTHONUTF8=1 python -m kaggle kernels list --mine`
   - 새 PC 에서는 `kaggle.exe` 가 PATH 에 없을 수 있다. 그래서 이 문서의 명령은 모두 `python -m kaggle` 로 쓴다.
   - Windows 에서는 `PYTHONUTF8=1` 을 붙인다(cp949 오류 회피). PowerShell: `$env:PYTHONUTF8=1`

## 쓰는 순서

```bash
cd ~/kaggle

# 1) 작업 파일(job json)로 노트북 폴더 만들기
python build_krea_batch.py <job_img.json> --slug krea-이름 [--ids c01,c02] [--seeds 1,2] [--steps 8]
python build_song_batch.py ace  <job_song.json> --slug ace-이름  [--styles a,b] [--seeds 5,23] [--seconds 215]
python build_song_batch.py yue2 <job_song.json> --slug yue2-이름
python build_ltx_batch.py <ltx_shots.json> --slug ltx-이름 [--res 704|480] [--only c01,c02]   # 사진 → 영상(소리), 11/2 추가 · CODEX.md 2-1

# 2) 올리기 → 끝날 때까지 대기 → 내려받기 → 노트북 삭제 (한 번에)
python kg.py run krea-이름 --to <결과를 복사할 폴더>

# 내 노트북 · 상태
python kg.py list

# 이번 주 GPU 사용량 · 남은 시간 (주 30시간, TPU 는 우리 모델에 못 쓴다)
PYTHONUTF8=1 python -m kaggle quota
```

- 결과는 `~/kaggle/<이름>-out/outputs/` 에 남고, `--to` 폴더에도 복사된다. `log.json` 에 컷 · 곡마다 걸린 시간이 있다.
- 오래 걸리므로 백그라운드로 돌린다(Claude Code: run_in_background, Codex: 백그라운드 터미널).

### job 형식 (Runpod 작업과 같다)

```json
{"seeds": [1], "images": {"c01": {"ratio": "16:9hd", "prompt": "..."}}}
```
비율: `16:9hd`(1920×1088) · `9:16hd`(1088×1920) · `16:9` · `9:16` · `4:3` · `3:4` · `1:1`

```json
{"lyrics": "[Verse 1]\n...", "language": "ko", "seconds": 215, "bpm": 96, "key": "C major",
 "seeds": [5, 23], "styles": {"이름": "스타일 문구"}}
```

## 알아 둘 것

- **GPU 일괄 세션은 동시에 2개까지.** 넘으면 push 가 거절된다 → `kg.py` 가 90초마다 다시 시도한다. 여러 창(세션)이 같은 계정을 쓰면 자리를 나눠 쓴다.
- 실행 중에는 로그를 볼 수 없다(상태만). 끝나야 결과 · 로그가 나온다.
- 세션마다 모델을 다시 받는다: 준비 Krea · ACE 약 9분, YuE2 약 2분.
- 속도: Krea 2 1920×1088 장당 약 155초 · ACE-Step 215초 곡 약 11분 · YuE2 240초 곡 약 25분(최대 240초). Runpod 보다 3~4배 느리다 → 급하지 않은 스틸 · 테이크용.
- 한 묶음은 12컷 안팎으로 나눠 두 자리에 동시에 올리면 절반 시간에 끝난다.
- 끝난 노트북은 지운다(`kg.py` 가 자동 삭제). 빌더가 언제든 다시 만든다. `notebookc6fe785625` 는 대표가 직접 만든 것이라 건드리지 않는다.
- 이미지 프롬프트: 인물 묘사에 smile 을 넣으면 슬픈 장면에서도 웃는다 → 표정은 컷마다 따로 쓴다. 글자(간판 · 상표 · 한글)는 틀리게 그린다 → 글자 없는 디자인으로.
- ACE-Step 은 구간별 악기 지시(무반주 시작 등)를 가사 태그 `[Verse 1 - a cappella]` + 스타일 문구 양쪽에 써야 따른다. YuE2 는 스타일 문구만으로 후반 고음이 안 올라간다.
- 미확인: 결과물 상업 이용 약관.

## 폴더

| 경로 | 내용 |
|---|---|
| `build_krea_batch.py` · `build_song_batch.py` | job json → 노트북 폴더 |
| `kg.py` | 올리기 · 대기 · 내려받기 · 삭제 |
| `krea-src` · `src-ace-step` · `src-yue2-music` | 원본 노트북(빌더가 읽는다, 지우지 말 것) |
| `jobs/` | 시험에 쓴 작업 파일 |
| `<이름>/` · `<이름>-out/` | 올린 노트북 · 내려받은 결과 |

## 다른 계정으로 돌리기 (2026-10-15)
- 토큰을 `~/.kaggle-<계정>/access_token` 에 둔다(예: `~/.kaggle-elrohm0119`). 기본 계정은 `~/.kaggle`(motionchoi).
- 빌드: `python build_song_batch.py ace <job> --slug <이름> --user <계정>`
- 실행: `KAGGLE_CONFIG_DIR=~/.kaggle-<계정> python kg.py run <이름> --to <폴더>` — kg.py 가 그 폴더의 토큰을 `KAGGLE_API_TOKEN` 으로 넘긴다(Kaggle CLI 2.2 는 CONFIG_DIR 의 access_token 을 읽지 않는다). 사용 시간은 `usage-.kaggle-<계정>.csv` 에 따로 적힌다.
- 수동 명령: `KAGGLE_API_TOKEN=$(cat ~/.kaggle-<계정>/access_token) python -m kaggle kernels status <계정>/<이름>`

## 옛 결과 보관 (2026-10-30)
- C: 공간 부족으로 10/12~10/16 노트북 · 결과 폴더 106개(2.37GB)를 `F:\kaggle\` 로 옮겼다(같은 이름). 빌더 · kg.py · 원본 노트북은 그대로 여기 있다.
- 나머지도 옮길 때는 같은 `F:\kaggle\` 로 합친 뒤 `~/kaggle`(C: 사용자 폴더) 자리에 정션(mklink /J)을 남길 예정.
