# -*- coding: utf-8 -*-
"""공식 ACE-Step 1.5 코드(cover · lego · repaint 등)를 Kaggle 에서 돌리는 노트북 폴더를 만든다.
사용: python build_ace_official.py <작업.py> --slug 이름 --dataset 계정/데이터셋 [--user 계정]
  <작업.py> 는 Pod 에서 쓰던 스크립트(cover.py · lego.py 형식). 경로는 노트북이 바꿔 준다:
    /workspace/ACE-Step-1.5 · /root/ACE-Step-1.5 → /kaggle/working/ACE-Step-1.5
    /workspace/<파일>        → /kaggle/input/<데이터셋>/<파일>   (입력)
    /workspace/*_out         → /kaggle/working/outputs           (결과)
  T4(16GB) 라서 기본은 2B turbo(config acestep-v15-turbo, 8스텝). XL 은 메모리가 모자랄 수 있다.
"""
import argparse, io, json, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
ap = argparse.ArgumentParser()
ap.add_argument("script")
ap.add_argument("--slug", required=True)
ap.add_argument("--dataset", required=True)
ap.add_argument("--user", default=os.environ.get("KAGGLE_USER", "motionchoi"))
ap.add_argument("--config", default="acestep-v15-turbo")
ap.add_argument("--steps", type=int, default=8)
a = ap.parse_args()

ds_dir = "/kaggle/working/in"   # 실행 때 /kaggle/input 아래에서 데이터셋 폴더를 찾아 링크한다(마운트 위치가 바뀜)
src = io.open(a.script, encoding="utf-8").read()
src = re.sub(r'/(workspace|root)/ACE-Step-1\.5', "/kaggle/working/ACE-Step-1.5", src)
src = re.sub(r'Path\("/workspace/\w+_out"\)', 'Path("/kaggle/working/outputs")', src)
src = re.sub(r'/workspace/', ds_dir + "/", src)
src = re.sub(r'config_path="[^"]+"', f'config_path="{a.config}"', src)
src = re.sub(r"inference_steps=\d+", f"inference_steps={a.steps}", src)
if "turbo" in a.config:
    src = src.replace("guidance_scale=7.0", "guidance_scale=1.0")
# 한 개 만들면 끝낸다(ONE=1) — T4 에서 두 번째 생성부터 GPU 메모리가 안 비워져 OOM 이 났다(10/25)
src = re.sub(r'(\n( +)print\(tag, "OK".*\n)',
             lambda m: m.group(1) + m.group(2) + 'if __import__("os").environ.get("ONE"): raise SystemExit(0)\n', src)

setup = r'''import os, subprocess, sys, time
t0 = time.time()
def sh(c):
    print("$", c, flush=True)
    r = subprocess.run(c, shell=True, text=True, capture_output=True)
    print(r.stdout[-3000:], r.stderr[-3000:], flush=True)
    if r.returncode: raise SystemExit(f"실패: {c}")
os.environ.update(UV_HTTP_TIMEOUT="300", UV_LINK_MODE="copy", HF_HOME="/kaggle/working/hf_cache")
# 데이터셋 폴더 찾기 — 마운트 위치가 /kaggle/input/<이름> 이 아닐 때가 있다
ds = None
for d, _, fs in os.walk("/kaggle/input"):
    if fs and not d.endswith("__MACOSX"):
        ds = d; break
print("dataset dir:", ds, os.listdir(ds) if ds else None, flush=True)
if os.path.lexists("/kaggle/working/in"): os.remove("/kaggle/working/in")
os.symlink(ds, "/kaggle/working/in")
sh("pip install -q uv")
os.chdir("/kaggle/working")
sh("git clone -q --depth 1 https://github.com/ace-step/ACE-Step-1.5.git")
os.chdir("/kaggle/working/ACE-Step-1.5")
# T4(Turing)는 bf16 이 없어 코드가 float16 을 고르는데, cover · lego 에서 NaN 이 난다(10/25) → float32 로 바꾼다
sh("sed -i 's/self.dtype = torch.float16/self.dtype = torch.float32/' acestep/core/generation/handler/init_service_orchestrator.py && grep -n 'torch.float32' acestep/core/generation/handler/init_service_orchestrator.py | head -3")
sh("uv sync 2>&1 | tail -3")
sh("uvx --from huggingface_hub hf download ACE-Step/Ace-Step1.5 --local-dir checkpoints > /kaggle/working/dl.log 2>&1; du -sh checkpoints/*")
print("SETUP_DONE", round(time.time() - t0), "s", flush=True)
'''
run = r'''import subprocess, os
os.environ["MPLBACKEND"] = "Agg"   # 노트북의 matplotlib_inline 값이 넘어가면 하위 프로세스가 죽는다
os.makedirs("/kaggle/working/outputs", exist_ok=True)
open("/kaggle/working/job.py", "w", encoding="utf-8").write(JOB)
# 테이크마다 프로세스를 새로 띄운다(ONE=1). 남은 게 없으면 스크립트가 *_DONE 을 찍는다
env = dict(os.environ, ONE="1", PYTORCH_CUDA_ALLOC_CONF="expandable_segments:True")
log = ""
for i in range(40):
    r = subprocess.run("cd /kaggle/working/ACE-Step-1.5 && .venv/bin/python /kaggle/working/job.py", shell=True, text=True, capture_output=True, env=env)
    print(i, [l for l in r.stdout.splitlines() if " OK " in l or "ERROR" in l or "_DONE" in l], flush=True)
    log += r.stdout + "\n" + r.stderr[-4000:] + "\n"
    if "_DONE" in r.stdout or " OK " not in r.stdout:
        break
open("/kaggle/working/outputs/log.txt", "w", encoding="utf-8").write(log[-200000:])
# 용량을 줄이려 설치물은 지운다(결과만 남김)
subprocess.run("rm -rf /kaggle/working/ACE-Step-1.5 /kaggle/working/hf_cache", shell=True)
'''
cell = lambda s: {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": s}
nb = {"nbformat": 4, "nbformat_minor": 5, "metadata": {"kernelspec": {"name": "python3", "display_name": "Python 3", "language": "python"}},
      "cells": [cell(setup), cell("JOB = " + json.dumps(src, ensure_ascii=False)), cell(run)]}
out = os.path.join(HERE, a.slug)
os.makedirs(out, exist_ok=True)
json.dump(nb, io.open(os.path.join(out, a.slug + ".ipynb"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
meta = {"id": f"{a.user}/{a.slug}", "title": a.slug, "code_file": a.slug + ".ipynb", "language": "python", "kernel_type": "notebook",
        "is_private": True, "enable_gpu": True, "enable_tpu": False, "enable_internet": True, "keywords": [],
        "dataset_sources": [a.dataset], "kernel_sources": [], "competition_sources": [], "model_sources": [], "machine_shape": "NvidiaTeslaT4"}
json.dump(meta, io.open(os.path.join(out, "kernel-metadata.json"), "w", encoding="utf-8"), indent=1)
print("->", out)
