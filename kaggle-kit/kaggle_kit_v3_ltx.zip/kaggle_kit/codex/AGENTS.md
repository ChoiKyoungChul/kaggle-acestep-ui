# 전역 지침

- 답변은 한국어로 한다.

## Kaggle 무료 GPU (ACE-Step · Krea 2 · YuE2 · LTX-2.5 영상)

곡 · 이미지를 Kaggle 로 만들 때는 **`~/kaggle/CODEX.md` 를 먼저 읽고 그 순서만 따른다.**
- ACE-Step · Krea · YuE2 를 PC 에 설치하거나 GitHub 저장소를 clone 하거나 Kaggle 노트북을 새로 짜지 않는다. 빌더가 만든 노트북이 Kaggle 안에서 다 한다.
- 순서: 작업 json → `python build_song_batch.py ace <json> --slug ace-<이름>` → `python kg.py run ace-<이름> --to <폴더>`(백그라운드) → 사용자가 듣고 고름.
- 영상(LTX): `python build_ltx_batch.py <ltx_shots.json> --slug ltx-<이름>` → 같은 `kg.py run`. HF 토큰 필요 없음.
- 모든 명령 앞에 `PYTHONUTF8=1`(PowerShell `$env:PYTHONUTF8=1`). 토큰 계정이 motionchoi 가 아니면 `--user <아이디>` 또는 `KAGGLE_USER`.
- 실행 중 로그가 안 보여도 정상(준비 9분 + 곡당 11분). 재업로드 · 다른 방법 찾기 금지. 오류면 `<이름>-out/*.log` 를 읽고 빌더를 고친다.
- 네트워크가 막히면 사용자에게 권한 허용을 요청한다(우회 금지).
- 토큰 파일 내용을 출력 · 기록하지 않는다. 남이 만든 노트북 · 결과 폴더는 지우지 않는다.
- 끝나면 `python kg.py usage` 로 사용 · 남은 시간을 알린다.
