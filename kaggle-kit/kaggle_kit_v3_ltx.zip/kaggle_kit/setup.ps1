﻿# Kaggle 작업 묶음 설치 — 압축을 푼 폴더에서 실행:  powershell -ExecutionPolicy Bypass -File setup.ps1 -User <Kaggle 아이디>
# 하는 일: ~/kaggle 에 빌더 · kg.py · 원본 노트북 복사 → Codex 지침 연결 → kaggle CLI 설치 → 토큰 · 인증 확인
# -SkipCopy: 이미 작업 중인 ~/kaggle 이 있을 때 파일은 건드리지 않고 CLI 설치 · 인증 확인만 한다.
param([string]$User = "", [switch]$SkipCopy)
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$env:PYTHONUTF8 = "1"
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)

if ($SkipCopy) {
    Write-Host "[1/5] 기존 ~/kaggle 폴더를 그대로 둡니다 (파일 복사 건너뜀)"
} else {
    Write-Host "[1/5] ~/kaggle 로 파일 복사 (같은 이름의 파일이 이미 있으면 덮어쓰지 않고 건너뜀)"
    $srcRoot = (Resolve-Path -LiteralPath "$here\kaggle").Path
    $dstRoot = "$HOME\kaggle"
    New-Item -ItemType Directory -Force $dstRoot | Out-Null
    $copied = 0
    $skipped = New-Object System.Collections.Generic.List[string]
    foreach ($f in (Get-ChildItem -LiteralPath $srcRoot -Recurse -File)) {
        $rel = $f.FullName.Substring($srcRoot.Length).TrimStart('\')
        $target = Join-Path $dstRoot $rel
        if (Test-Path -LiteralPath $target) { $skipped.Add($rel); continue }
        New-Item -ItemType Directory -Force (Split-Path -Parent $target) | Out-Null
        Copy-Item -LiteralPath $f.FullName -Destination $target
        $copied++
    }
    Write-Host "  새로 복사 $copied 개 · 기존 파일 보존 $($skipped.Count) 개"
    if ($skipped.Count -gt 0) {
        Write-Host "  보존한 파일(덮어쓰지 않음):" -ForegroundColor Yellow
        $skipped | Select-Object -First 15 | ForEach-Object { Write-Host "    $_" }
        if ($skipped.Count -gt 15) { Write-Host "    … 외 $($skipped.Count - 15) 개" }
    }
    if ($User -and -not $skipped.Contains('gpu-check\kernel-metadata.json')) {
        # 원본 gpu-check 는 motionchoi 계정용 → 방금 복사한 파일만 이 PC 계정으로 바꾼다(안 바꾸면 push 403)
        $meta = "$dstRoot\gpu-check\kernel-metadata.json"
        if (Test-Path $meta) {
            $json = [IO.File]::ReadAllText($meta, $utf8NoBom)
            $json = $json -replace '"id"\s*:\s*"[^"/]+/gpu-check"', ('"id":"' + $User + '/gpu-check"')
            [IO.File]::WriteAllText($meta, $json, $utf8NoBom)
            Write-Host "  gpu-check 노트북 계정을 $User 로 맞춤"
        }
    }
}

Write-Host "[2/5] Codex 지침 (~/.codex/AGENTS.md)"
New-Item -ItemType Directory -Force "$HOME\.codex" | Out-Null
$agents = "$HOME\.codex\AGENTS.md"
if (-not (Test-Path $agents)) {
    Copy-Item "$here\codex\AGENTS.md" $agents
    Write-Host "  새로 만듦"
} elseif ((Get-Content $agents -Raw -Encoding UTF8) -notmatch "CODEX\.md") {
    Copy-Item $agents "$agents.bak"
    $block = (Get-Content "$here\codex\AGENTS.md" -Raw -Encoding UTF8) -replace "(?s)^.*?(## Kaggle)", '$1'
    Add-Content -Path $agents -Value "`n$block" -Encoding UTF8
    Write-Host "  기존 파일 뒤에 Kaggle 지침 추가 (원본 AGENTS.md.bak)"
} else {
    Write-Host "  이미 연결됨"
}

Write-Host "[3/5] kaggle CLI"
python -m pip install --quiet --disable-pip-version-check "kaggle==2.2.4"   # 검증한 버전으로 고정
if ($LASTEXITCODE -ne 0) {
    Write-Host "  kaggle CLI 설치 실패: 인터넷 연결을 확인하고 다시 실행하세요." -ForegroundColor Red
    exit 1
}
python -m kaggle --version
if ($LASTEXITCODE -ne 0) {
    Write-Host "  kaggle CLI 를 실행하지 못했습니다." -ForegroundColor Red
    exit 1
}

Write-Host "[4/5] 계정 이름"
if ($User) {
    [Environment]::SetEnvironmentVariable("KAGGLE_USER", $User, "User")
    $env:KAGGLE_USER = $User
    Write-Host "  KAGGLE_USER=$User (사용자 환경변수로 저장, 새 창부터 적용)"
} else {
    Write-Host "  -User 를 안 줌 → 빌더 기본 motionchoi. 다른 계정이면 -User <아이디> 로 다시 실행"
}

Write-Host "[5/5] 토큰 · 인증 확인"
if (-not (Test-Path "$HOME\.kaggle\access_token")) {
    Write-Host "  토큰 없음: kaggle.com > Settings > API > Create New Token 후 $HOME\.kaggle\access_token 에 저장하고 다시 실행" -ForegroundColor Yellow
    exit 1
}
python -m kaggle kernels list --mine --page-size 3
if ($LASTEXITCODE -ne 0) {
    Write-Host "  인증 실패: Kaggle 아이디와 토큰이 같은 계정인지, 휴대폰 인증이 됐는지 확인하세요." -ForegroundColor Red
    exit 1
}
Write-Host "완료. 휴대폰 인증이 안 된 계정이면 GPU 가 붙지 않습니다 (kaggle.com Settings)." -ForegroundColor Green
Write-Host "Codex 에게는 '~/kaggle/CODEX.md 대로 곡 만들어줘' 라고 요청하세요."
exit 0
